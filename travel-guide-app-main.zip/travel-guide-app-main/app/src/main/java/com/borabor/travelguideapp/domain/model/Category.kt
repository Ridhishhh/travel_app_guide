package com.borabor.travelguideapp.domain.model

data class Category(
    val icon: String,
    val id: String,
    val title: String
)