package com.borabor.travelguideapp.util

enum class ListType {
    ALL,
    DEALS,
    TOP_DESTINATIONS,
    NEARBY_ATTRACTIONS,
    TRIP_LOCATIONS,
    MIGHT_NEEDS,
    TOP_PICK_ARTICLES
}